package com.cg.service;

import com.cg.exception.StudentException;

public interface Service {
	public void Entry(String s, int i, double j);
	public boolean validatename(String s) throws StudentException;
	public boolean validateage(int i) throws StudentException;
	public boolean validatesalary(double t) throws StudentException;

}
