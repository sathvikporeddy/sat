package com.cg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.exception.StudentException;

public class ServiceImpl implements Service {

	@Override
	public void Entry(String s, int i, double j) {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public boolean validatename(String s)throws StudentException {
		if(s==null)
			throw new StudentException("Invalid name");
		else{
			Pattern pat = Pattern.compile("[A-Z][a-z]{3,12}");
			Matcher mat=pat.matcher(s);
			return mat.matches();
		}
	}

	@Override
	public boolean validateage(int i) throws StudentException {
		// TODO Auto-generated method stub
		if(i==0)
			throw new StudentException("invalid age");
		else{
			Pattern pat=Pattern.compile("[0-9]{1}[0-9]{1}");
			Matcher mat=pat.matcher(String.valueOf(i));
	        return mat.matches();
		}
	}

	@Override
	public boolean validatesalary(double t) throws StudentException {
		if(t==0)
			throw new StudentException("invalid salary");
		else
			
		// TODO Auto-generated method stub
		return false;
	}

}
