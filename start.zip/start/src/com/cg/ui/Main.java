package com.cg.ui;

import java.util.Scanner;

import com.cg.dto.Details;

public class Main {

	public static void main(String[] args) {
		Details det=new Details("sathvik",22,23114);
		// TODO Auto-generated method stub
		System.out.println("enter your choice");
		System.out.println("1. Add details");
		Scanner sc=new Scanner(System.in);
		int i=sc.nextInt();
		System.out.println("enter name");
		String name=sc.next();
		System.out.println("enter age");
		int age=sc.nextInt();
		double salary=sc.nextDouble();
		
	}

}
