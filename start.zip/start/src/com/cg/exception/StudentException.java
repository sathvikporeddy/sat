package com.cg.exception;

public class StudentException extends Exception {
public StudentException(String s){
	super(s);
}
}
